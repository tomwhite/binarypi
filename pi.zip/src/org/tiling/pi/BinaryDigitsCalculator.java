package org.tiling.pi;

public interface BinaryDigitsCalculator {

	/**
	 * Calculates the <i>n</i>th binary digit of a number (the number depends on the implementing class).
	 * @param n the <i>n</i>th digit to calculate.
	 * @throws IllegalArgumentException if n is less than 1 or possibly if n is too large (implementation dependent).
	 * @throws ValidityCheckFailedException if the calculation fails an internal validity check.
	 * @see ValidityCheckFailedException
 	 */
	public byte calculateNthBinaryDigit(int n) throws IllegalArgumentException, ValidityCheckFailedException;

}