package org.tiling.pi;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 * I check that {@link BinaryPiAlgorithm} and {@link BinaryPiSource} produce the
 * same expansion of pi.
 */
public class BinaryPiCheck {

	public static void main(String[] args) {

		try {

			BinaryDigitsCalculator algorithm = new BinaryPiAlgorithm();

			BinaryPiSource source = new BinaryPiSource(new BufferedReader(new FileReader(args[0])));

			for (int i = 1; i < source.getNumberOfBinaryDigits(); i++) {
				byte digit = algorithm.calculateNthBinaryDigit(i);
				byte digitCheck = source.calculateNthBinaryDigit(i);
				if (digit != digitCheck) {
					System.out.println(i + " mismatch");
					System.exit(1);
				}
				if (i % 100 == 0) {
					System.out.println(i);
				}
				//System.out.println(digit == digitCheck ? (i + "\t" + digit) : (i + " mismatch"));
			}

		
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}

	}
}
